// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var highScore = 1000
highScore = highScore + 50

for i in 0..<100 {
    highScore = highScore + i
}

var isActive = true

var myVarialbe : Int

let city = "Carpinteria"

var day = "Tuesday"

var temp = 75

println("The high for \(city) on \(day) is \(temp) degrees.")

func myFunction(name : String = "John Deo") {
    println("Hello, \(name)")
}

myFunction("Jane")
